"use client"

import { useState } from "react"
import { AuthProvider, useAuth } from "@/lib/auth-context"
import { LoginScreen } from "@/components/login-screen"
import { RegisterScreen } from "@/components/register-screen"
import { Dashboard } from "@/components/dashboard"

function AppContent() {
  const { user } = useAuth()
  const [view, setView] = useState<"login" | "register">("login")

  if (user) return <Dashboard />

  if (view === "register") {
    return <RegisterScreen onBack={() => setView("login")} />
  }

  return <LoginScreen onRegister={() => setView("register")} />
}

export default function Home() {
  return (
    <AuthProvider>
      <main className="max-w-md mx-auto min-h-screen bg-background shadow-2xl shadow-foreground/10 relative">
        <AppContent />
      </main>
    </AuthProvider>
  )
}
