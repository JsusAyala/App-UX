"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Eye, EyeOff, Shield, Loader2 } from "lucide-react"

export function LoginScreen({ onRegister }: { onRegister?: () => void }) {
  const { login, isLoading } = useAuth()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    
    if (!email || !password) {
      setError("Por favor ingresa tu correo y contrasena")
      return
    }

    const success = await login(email, password)
    if (!success) {
      setError("Credenciales incorrectas")
    }
  }

  return (
    <div className="min-h-screen bg-primary flex flex-col items-center justify-center p-4">
      {/* Logo area */}
      <div className="mb-10 text-center">
        <div className="flex items-center justify-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-xl bg-accent flex items-center justify-center">
            <Shield className="w-7 h-7 text-accent-foreground" />
          </div>
          <h1 className="text-3xl font-bold text-primary-foreground tracking-tight">NovaPay</h1>
        </div>
        <p className="text-primary-foreground/60 text-sm">Banca Digital Segura</p>
      </div>

      {/* Login card */}
      <div className="w-full max-w-sm">
        <div className="bg-card rounded-2xl p-6 shadow-2xl shadow-primary/30">
          <h2 className="text-xl font-semibold text-card-foreground mb-1">Bienvenido</h2>
          <p className="text-muted-foreground text-sm mb-6">Inicia sesion en tu cuenta</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-card-foreground mb-1.5">
                Correo electronico
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="tu@correo.com"
                className="w-full px-4 py-3 rounded-lg bg-secondary text-secondary-foreground placeholder:text-muted-foreground border border-border focus:outline-none focus:ring-2 focus:ring-ring text-sm transition-all"
                disabled={isLoading}
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-card-foreground mb-1.5">
                Contrasena
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Ingresa tu contrasena"
                  className="w-full px-4 py-3 rounded-lg bg-secondary text-secondary-foreground placeholder:text-muted-foreground border border-border focus:outline-none focus:ring-2 focus:ring-ring text-sm pr-12 transition-all"
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-card-foreground transition-colors"
                  aria-label={showPassword ? "Ocultar contrasena" : "Mostrar contrasena"}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg px-4 py-2.5">
                <p className="text-destructive text-sm">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-lg bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 disabled:opacity-70 transition-all flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Verificando...
                </>
              ) : (
                "Iniciar Sesion"
              )}
            </button>
          </form>

          <div className="mt-5 text-center space-y-2">
            <button className="text-sm text-primary hover:underline block mx-auto">
              Olvidaste tu contrasena?
            </button>
            {onRegister && (
              <button onClick={onRegister} className="text-sm text-card-foreground hover:text-primary transition-colors block mx-auto">
                No tienes cuenta? <span className="font-semibold text-primary underline">Registrate aqui</span>
              </button>
            )}
          </div>
        </div>

        <p className="text-center text-primary-foreground/40 text-xs mt-6">
          Protegido con encriptacion de 256-bit
        </p>
      </div>
    </div>
  )
}
