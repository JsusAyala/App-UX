"use client"

import { useState } from "react"
import {
  Shield,
  ArrowLeft,
  ArrowRight,
  Eye,
  EyeOff,
  Check,
  X,
  Loader2,
  Mail,
  CheckCircle2,
} from "lucide-react"

/* ------------------------------------------------------------------ */
/*  Password rules (reasonable)                                        */
/* ------------------------------------------------------------------ */
const PASSWORD_RULES = [
  { id: "length", label: "Minimo 8 caracteres", test: (p: string) => p.length >= 8 },
  { id: "upper", label: "Al menos una letra mayuscula", test: (p: string) => /[A-Z]/.test(p) },
  { id: "lower", label: "Al menos una letra minuscula", test: (p: string) => /[a-z]/.test(p) },
  { id: "number", label: "Al menos un numero", test: (p: string) => /\d/.test(p) },
]

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface FormData {
  nombre: string
  apellido: string
  correo: string
  telefono: string
  password: string
  confirmPassword: string
}

const INITIAL_FORM: FormData = {
  nombre: "",
  apellido: "",
  correo: "",
  telefono: "",
  password: "",
  confirmPassword: "",
}

/* ================================================================== */
/*  Component                                                          */
/* ================================================================== */
export function RegisterScreen({ onBack }: { onBack: () => void }) {
  const [step, setStep] = useState(0) // 0 = datos, 1 = contrasena, 2 = verificacion email, 3 = exito
  const [form, setForm] = useState<FormData>(INITIAL_FORM)
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({})
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)

  /* verification states */
  const [emailCode, setEmailCode] = useState("")
  const [emailSent, setEmailSent] = useState(false)
  const [verifying, setVerifying] = useState(false)
  const [verificationError, setVerificationError] = useState("")

  /* helpers */
  const set = (key: keyof FormData, val: string) => {
    setForm((p) => ({ ...p, [key]: val }))
    setErrors((p) => {
      const n = { ...p }
      delete n[key]
      return n
    })
  }

  /* ---------------------------------------------------------------- */
  /*  Validators per form step                                         */
  /* ---------------------------------------------------------------- */
  const validateStep = (): boolean => {
    const e: Partial<Record<keyof FormData, string>> = {}

    if (step === 0) {
      if (!form.nombre.trim()) e.nombre = "Campo obligatorio"
      if (!form.apellido.trim()) e.apellido = "Campo obligatorio"
      if (!form.correo.trim()) e.correo = "Campo obligatorio"
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.correo)) e.correo = "Correo invalido"
      if (!form.telefono.trim()) e.telefono = "Campo obligatorio"
      else if (form.telefono.length !== 10) e.telefono = "Debe tener 10 digitos"
    }

    if (step === 1) {
      const allPass = PASSWORD_RULES.every((r) => r.test(form.password))
      if (!form.password) e.password = "Campo obligatorio"
      else if (!allPass) e.password = "La contrasena no cumple todos los requisitos"
      if (!form.confirmPassword) e.confirmPassword = "Campo obligatorio"
      else if (form.confirmPassword !== form.password) e.confirmPassword = "Las contrasenas no coinciden"
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  /* ---------------------------------------------------------------- */
  /*  Navigation                                                       */
  /* ---------------------------------------------------------------- */
  const next = () => {
    if (validateStep()) setStep((s) => s + 1)
  }

  const prev = () => {
    if (step > 0 && step < 3) {
      setVerificationError("")
      setStep((s) => s - 1)
    }
  }

  /* ---------------------------------------------------------------- */
  /*  Verification actions (work correctly)                            */
  /* ---------------------------------------------------------------- */
  const sendEmailCode = async () => {
    setEmailSent(true)
  }

  const verifyEmail = async () => {
    setVerifying(true)
    setVerificationError("")
    await new Promise((r) => setTimeout(r, 1500))

    if (emailCode === "000000") {
      setVerificationError("Codigo incorrecto. Intenta de nuevo.")
      setVerifying(false)
      return
    }

    // Any 6-digit code works (simulated success)
    setVerifying(false)
    setStep(3) // Success!
  }

  /* ---------------------------------------------------------------- */
  /*  Shared input component                                           */
  /* ---------------------------------------------------------------- */
  const Input = ({
    label,
    field,
    type = "text",
    placeholder = "",
    maxLength,
  }: {
    label: string
    field: keyof FormData
    type?: string
    placeholder?: string
    maxLength?: number
  }) => (
    <div>
      <label className="block text-sm font-medium text-card-foreground mb-1.5">
        {label}
      </label>
      <input
        type={type}
        value={form[field]}
        onChange={(e) => set(field, e.target.value)}
        placeholder={placeholder}
        maxLength={maxLength}
        className={`w-full px-4 py-3 rounded-lg bg-secondary text-secondary-foreground placeholder:text-muted-foreground border text-sm transition-all focus:outline-none focus:ring-2 ${
          errors[field]
            ? "border-destructive focus:ring-destructive/40"
            : "border-border focus:ring-ring"
        }`}
      />
      {errors[field] && (
        <p className="text-destructive text-xs mt-1">{errors[field]}</p>
      )}
    </div>
  )

  /* ---------------------------------------------------------------- */
  /*  Step titles & progress                                           */
  /* ---------------------------------------------------------------- */
  const STEP_LABELS = [
    "Datos Personales",
    "Contrasena",
    "Verificar Email",
    "Cuenta Creada",
  ]

  const totalSteps = STEP_LABELS.length
  const progressPercent = ((step + 1) / totalSteps) * 100

  /* ================================================================ */
  /*  RENDER                                                           */
  /* ================================================================ */
  return (
    <div className="min-h-screen bg-primary flex flex-col">
      {/* Header */}
      <div className="px-4 pt-6 pb-4">
        <div className="flex items-center gap-3 mb-4">
          {step < 3 && (
            <button
              onClick={step === 0 ? onBack : prev}
              className="text-primary-foreground/80 hover:text-primary-foreground transition-colors"
              aria-label="Volver"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
              <Shield className="w-5 h-5 text-accent-foreground" />
            </div>
            <span className="text-lg font-bold text-primary-foreground">
              NovaPay
            </span>
          </div>
        </div>

        <h2 className="text-xl font-bold text-primary-foreground mb-1">
          {step < 3 ? "Crear Cuenta" : "Registro Exitoso"}
        </h2>
        <p className="text-primary-foreground/60 text-sm">
          Paso {Math.min(step + 1, totalSteps)} de {totalSteps}:{" "}
          {STEP_LABELS[step]}
        </p>

        {/* Progress bar */}
        <div className="mt-3 h-1.5 bg-primary-foreground/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-accent rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Form area */}
      <div className="flex-1 bg-card rounded-t-3xl p-5 overflow-y-auto">
        {/* ============ STEP 0 : Datos Personales ============ */}
        {step === 0 && (
          <div className="space-y-4">
            <Input
              label="Nombre(s)"
              field="nombre"
              placeholder="Ej: Juan Carlos"
            />
            <Input
              label="Apellido(s)"
              field="apellido"
              placeholder="Ej: Garcia Lopez"
            />
            <Input
              label="Correo Electronico"
              field="correo"
              type="email"
              placeholder="tu@correo.com"
            />
            <Input
              label="Telefono Celular (10 digitos)"
              field="telefono"
              type="tel"
              placeholder="5512345678"
              maxLength={10}
            />
          </div>
        )}

        {/* ============ STEP 1 : Contrasena ============ */}
        {step === 1 && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-card-foreground mb-1.5">
                Contrasena
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={form.password}
                  onChange={(e) => set("password", e.target.value)}
                  placeholder="Crea tu contrasena"
                  className={`w-full px-4 py-3 pr-10 rounded-lg bg-secondary text-secondary-foreground placeholder:text-muted-foreground border text-sm transition-all focus:outline-none focus:ring-2 ${
                    errors.password
                      ? "border-destructive focus:ring-destructive/40"
                      : "border-border focus:ring-ring"
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-card-foreground"
                  aria-label="Toggle password"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
              {errors.password && (
                <p className="text-destructive text-xs mt-1">
                  {errors.password}
                </p>
              )}
            </div>

            {/* Live password rules */}
            <div className="bg-secondary/60 rounded-xl p-4 space-y-2">
              <p className="text-xs font-semibold text-card-foreground mb-1">
                Requisitos de contrasena:
              </p>
              {PASSWORD_RULES.map((rule) => {
                const pass =
                  form.password.length > 0 && rule.test(form.password)
                return (
                  <div key={rule.id} className="flex items-center gap-2">
                    {pass ? (
                      <Check className="w-3.5 h-3.5 text-accent flex-shrink-0" />
                    ) : (
                      <X className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                    )}
                    <span
                      className={`text-xs ${
                        pass ? "text-accent" : "text-muted-foreground"
                      }`}
                    >
                      {rule.label}
                    </span>
                  </div>
                )
              })}
            </div>

            <div>
              <label className="block text-sm font-medium text-card-foreground mb-1.5">
                Confirmar Contrasena
              </label>
              <div className="relative">
                <input
                  type={showConfirm ? "text" : "password"}
                  value={form.confirmPassword}
                  onChange={(e) => set("confirmPassword", e.target.value)}
                  placeholder="Repite tu contrasena"
                  className={`w-full px-4 py-3 pr-10 rounded-lg bg-secondary text-secondary-foreground placeholder:text-muted-foreground border text-sm transition-all focus:outline-none focus:ring-2 ${
                    errors.confirmPassword
                      ? "border-destructive focus:ring-destructive/40"
                      : "border-border focus:ring-ring"
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-card-foreground"
                  aria-label="Toggle confirm"
                >
                  {showConfirm ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
              {errors.confirmPassword && (
                <p className="text-destructive text-xs mt-1">
                  {errors.confirmPassword}
                </p>
              )}
            </div>
          </div>
        )}

        {/* ============ STEP 2 : Email Verification ============ */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="flex flex-col items-center text-center mb-2">
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                <Mail className="w-7 h-7 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-card-foreground">
                Verificacion por Email
              </h3>
              <p className="text-muted-foreground text-sm mt-1">
                Ingresa el codigo de 6 digitos enviado a{" "}
                <span className="font-medium text-card-foreground">
                  {form.correo}
                </span>
              </p>
            </div>

            {!emailSent ? (
              <button
                onClick={sendEmailCode}
                className="w-full py-3 rounded-lg bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-all"
              >
                Enviar Codigo
              </button>
            ) : (
              <>
                <input
                  type="text"
                  value={emailCode}
                  onChange={(e) => {
                    setEmailCode(e.target.value.replace(/\D/g, "").slice(0, 6))
                    setVerificationError("")
                  }}
                  placeholder="------"
                  maxLength={6}
                  className="w-full px-3 py-4 rounded-lg bg-secondary text-secondary-foreground border border-border text-center text-2xl font-mono tracking-[0.5em] focus:outline-none focus:ring-2 focus:ring-ring"
                />

                <button
                  onClick={verifyEmail}
                  disabled={emailCode.length !== 6 || verifying}
                  className="w-full py-3 rounded-lg bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                >
                  {verifying ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Verificando...
                    </>
                  ) : (
                    "Verificar Codigo"
                  )}
                </button>

                <p className="text-xs text-center text-muted-foreground">
                  Ingresa cualquier codigo de 6 digitos para continuar
                </p>
              </>
            )}

            {verificationError && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg px-4 py-3 flex items-start gap-2">
                <X className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                <p className="text-destructive text-sm">{verificationError}</p>
              </div>
            )}
          </div>
        )}

        {/* ============ STEP 3 : Success ============ */}
        {step === 3 && (
          <div className="flex flex-col items-center justify-center text-center py-8">
            <div className="w-20 h-20 rounded-full bg-accent/10 flex items-center justify-center mb-5">
              <CheckCircle2 className="w-10 h-10 text-accent" />
            </div>
            <h3 className="text-xl font-bold text-card-foreground mb-2">
              Cuenta Creada Exitosamente
            </h3>
            <p className="text-muted-foreground text-sm mb-6 leading-relaxed max-w-xs">
              Bienvenido a NovaPay, {form.nombre}. Tu cuenta ha sido creada
              correctamente. Ya puedes iniciar sesion con tu correo y contrasena.
            </p>
            <button
              onClick={onBack}
              className="w-full py-3 rounded-lg bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-all flex items-center justify-center gap-2"
            >
              Ir al Inicio de Sesion
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* ============ Navigation Buttons ============ */}
        {step < 2 && (
          <div className="flex items-center gap-3 mt-6">
            {step > 0 && (
              <button
                onClick={prev}
                className="flex-1 py-3 rounded-lg border border-border text-card-foreground font-medium text-sm hover:bg-secondary transition-all flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Anterior
              </button>
            )}
            <button
              onClick={next}
              className="flex-1 py-3 rounded-lg bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-all flex items-center justify-center gap-2"
            >
              Siguiente
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
