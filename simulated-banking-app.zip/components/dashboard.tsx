"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { 
  CreditCard, 
  Send, 
  FileText, 
  LogOut, 
  ArrowUpRight, 
  ArrowDownLeft,
  Smartphone,
  Zap,
  MoreHorizontal,
  Bell
} from "lucide-react"
import { TransferModal } from "./transfer-modal"
import { PaymentModal } from "./payment-modal"
import { StatementView } from "./statement-view"

type View = "home" | "statement"

export function Dashboard() {
  const { user, logout } = useAuth()
  const [view, setView] = useState<View>("home")
  const [showTransfer, setShowTransfer] = useState(false)
  const [showPayment, setShowPayment] = useState(false)
  const [showBalance, setShowBalance] = useState(true)
  const [hasNotification] = useState(true)

  if (!user) return null

  if (view === "statement") {
    return <StatementView onBack={() => setView("home")} />
  }

  const recentTransactions = [
    { id: 1, name: "Amazon MX", amount: -1249.99, date: "Hoy, 14:32", type: "debit" as const, icon: "cart" },
    { id: 2, name: "Transferencia recibida", amount: 5000.00, date: "Hoy, 09:15", type: "credit" as const, icon: "transfer" },
    { id: 3, name: "Netflix", amount: -219.00, date: "Ayer, 00:01", type: "debit" as const, icon: "entertainment" },
    { id: 4, name: "Uber Eats", amount: -387.50, date: "12 Feb, 21:45", type: "debit" as const, icon: "food" },
    { id: 5, name: "Nomina", amount: 28500.00, date: "10 Feb, 06:00", type: "credit" as const, icon: "salary" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary px-4 pt-6 pb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-primary-foreground/60 text-sm">Hola,</p>
            <h1 className="text-primary-foreground font-semibold text-lg">{user.name}</h1>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative" aria-label="Notificaciones">
              <Bell className="w-5 h-5 text-primary-foreground/80" />
              {hasNotification && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-destructive rounded-full" />
              )}
            </button>
            <button
              onClick={logout}
              className="p-2 rounded-lg bg-primary-foreground/10 text-primary-foreground/80 hover:bg-primary-foreground/20 transition-colors"
              aria-label="Cerrar sesion"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Balance Card */}
        <div className="bg-primary-foreground/10 backdrop-blur-sm rounded-2xl p-5 border border-primary-foreground/10">
          <div className="flex items-center justify-between mb-1">
            <p className="text-primary-foreground/60 text-sm">Saldo disponible</p>
            <button
              onClick={() => setShowBalance(!showBalance)}
              className="text-xs text-primary-foreground/50 hover:text-primary-foreground/80 transition-colors"
            >
              {showBalance ? "Ocultar" : "Mostrar"}
            </button>
          </div>
          <p className="text-3xl font-bold text-primary-foreground font-mono tracking-tight mb-3">
            {showBalance ? `$${user.balance.toLocaleString("es-MX", { minimumFractionDigits: 2 })}` : "$** *** **"}
          </p>
          <p className="text-primary-foreground/40 text-xs">{user.accountNumber}</p>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 -mt-4">
        <div className="bg-card rounded-2xl p-4 shadow-lg shadow-foreground/5">
          <div className="grid grid-cols-4 gap-2">
            <QuickAction
              icon={<Send className="w-5 h-5" />}
              label="Transferir"
              onClick={() => setShowTransfer(true)}
            />
            <QuickAction
              icon={<Smartphone className="w-5 h-5" />}
              label="Recargar"
              onClick={() => setShowPayment(true)}
            />
            <QuickAction
              icon={<Zap className="w-5 h-5" />}
              label="Pagar"
              onClick={() => setShowPayment(true)}
            />
            <QuickAction
              icon={<MoreHorizontal className="w-5 h-5" />}
              label="Mas"
              onClick={() => {}}
            />
          </div>
        </div>
      </div>

      {/* Account Statement Button */}
      <div className="px-4 mt-4">
        <button
          onClick={() => setView("statement")}
          className="w-full flex items-center justify-between bg-card rounded-xl p-4 shadow-sm border border-border hover:bg-secondary/50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="w-5 h-5 text-primary" />
            </div>
            <div className="text-left">
              <p className="text-sm font-medium text-card-foreground">Estado de Cuenta</p>
              <p className="text-xs text-muted-foreground">Febrero 2026</p>
            </div>
          </div>
          <ArrowUpRight className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {/* Recent Transactions */}
      <div className="px-4 mt-6 pb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-foreground">Movimientos Recientes</h2>
          <button className="text-xs text-primary font-medium">Ver todos</button>
        </div>

        <div className="space-y-3">
          {recentTransactions.map((tx) => (
            <div
              key={tx.id}
              className="flex items-center justify-between bg-card rounded-xl p-3.5 border border-border"
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  tx.type === "credit" 
                    ? "bg-accent/10" 
                    : "bg-secondary"
                }`}>
                  {tx.type === "credit" ? (
                    <ArrowDownLeft className="w-5 h-5 text-accent" />
                  ) : (
                    <CreditCard className="w-5 h-5 text-muted-foreground" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-card-foreground">{tx.name}</p>
                  <p className="text-xs text-muted-foreground">{tx.date}</p>
                </div>
              </div>
              <p className={`text-sm font-semibold font-mono ${
                tx.type === "credit" ? "text-accent" : "text-card-foreground"
              }`}>
                {tx.type === "credit" ? "+" : "-"}${Math.abs(tx.amount).toLocaleString("es-MX", { minimumFractionDigits: 2 })}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Modals */}
      {showTransfer && <TransferModal onClose={() => setShowTransfer(false)} />}
      {showPayment && <PaymentModal onClose={() => setShowPayment(false)} />}
    </div>
  )
}

function QuickAction({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1.5 py-2 rounded-xl hover:bg-secondary/50 transition-colors"
    >
      <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center text-primary">
        {icon}
      </div>
      <span className="text-xs text-card-foreground font-medium">{label}</span>
    </button>
  )
}
