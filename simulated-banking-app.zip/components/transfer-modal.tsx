"use client"

import { useState } from "react"
import { X, Loader2, ArrowRight, CheckCircle2 } from "lucide-react"

type TransferStep = "form" | "confirming" | "success"

export function TransferModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState<TransferStep>("form")
  const [clabe, setClabe] = useState("")
  const [amount, setAmount] = useState("")
  const [concept, setConcept] = useState("")
  const [beneficiary, setBeneficiary] = useState("")
  const [folio, setFolio] = useState("")

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault()
    setStep("confirming")

    // Simula un procesamiento de 2 segundos
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Genera un folio aleatorio
    const randomFolio = `SPEI-${Date.now().toString().slice(-8)}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`
    setFolio(randomFolio)
    setStep("success")
  }

  return (
    <div className="fixed inset-0 bg-foreground/50 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center">
      <div className="bg-card w-full max-w-md rounded-t-2xl sm:rounded-2xl max-h-[90vh] overflow-y-auto animate-in slide-in-from-bottom-4 duration-300">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="font-semibold text-card-foreground">Transferencia SPEI</h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-secondary transition-colors"
            aria-label="Cerrar"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        {step === "form" && (
          <form onSubmit={handleTransfer} className="p-4 space-y-4">
            <div>
              <label htmlFor="beneficiary" className="block text-sm font-medium text-card-foreground mb-1.5">
                Beneficiario
              </label>
              <input
                id="beneficiary"
                type="text"
                value={beneficiary}
                onChange={(e) => setBeneficiary(e.target.value)}
                placeholder="Nombre del beneficiario"
                required
                className="w-full px-4 py-3 rounded-lg bg-secondary text-secondary-foreground placeholder:text-muted-foreground border border-border focus:outline-none focus:ring-2 focus:ring-ring text-sm"
              />
            </div>

            <div>
              <label htmlFor="clabe" className="block text-sm font-medium text-card-foreground mb-1.5">
                CLABE Interbancaria
              </label>
              <input
                id="clabe"
                type="text"
                value={clabe}
                onChange={(e) => setClabe(e.target.value)}
                placeholder="18 digitos"
                maxLength={18}
                required
                className="w-full px-4 py-3 rounded-lg bg-secondary text-secondary-foreground placeholder:text-muted-foreground border border-border focus:outline-none focus:ring-2 focus:ring-ring text-sm font-mono"
              />
            </div>

            <div>
              <label htmlFor="amount" className="block text-sm font-medium text-card-foreground mb-1.5">
                Monto
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-sm font-mono">$</span>
                <input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="1"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  required
                  className="w-full pl-8 pr-4 py-3 rounded-lg bg-secondary text-secondary-foreground placeholder:text-muted-foreground border border-border focus:outline-none focus:ring-2 focus:ring-ring text-sm font-mono"
                />
              </div>
            </div>

            <div>
              <label htmlFor="concept" className="block text-sm font-medium text-card-foreground mb-1.5">
                Concepto (opcional)
              </label>
              <input
                id="concept"
                type="text"
                value={concept}
                onChange={(e) => setConcept(e.target.value)}
                placeholder="Ej: Pago de renta"
                className="w-full px-4 py-3 rounded-lg bg-secondary text-secondary-foreground placeholder:text-muted-foreground border border-border focus:outline-none focus:ring-2 focus:ring-ring text-sm"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 rounded-lg bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-all flex items-center justify-center gap-2"
              >
                Enviar Transferencia
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}

        {step === "confirming" && (
          <div className="p-8 flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Loader2 className="w-8 h-8 text-primary animate-spin" />
            </div>
            <div className="text-center">
              <p className="font-semibold text-card-foreground mb-1">Procesando transferencia...</p>
              <p className="text-sm text-muted-foreground">
                Verificando datos con el banco destino
              </p>
            </div>
            <div className="flex gap-1 mt-2">
              <div className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:0ms]" />
              <div className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:150ms]" />
              <div className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:300ms]" />
            </div>
          </div>
        )}

        {step === "success" && (
          <div className="p-6 flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-accent" />
            </div>
            <div className="text-center">
              <p className="font-semibold text-card-foreground mb-2">Transferencia Exitosa</p>
              <p className="text-sm text-muted-foreground mb-4">
                Tu transferencia ha sido procesada correctamente.
              </p>
            </div>

            <div className="w-full bg-secondary rounded-xl p-4 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Beneficiario</span>
                <span className="font-medium text-card-foreground">{beneficiary}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">CLABE</span>
                <span className="font-mono text-card-foreground text-xs">
                  {"****" + clabe.slice(-4)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Monto</span>
                <span className="font-semibold text-card-foreground font-mono">
                  ${Number(amount).toLocaleString("es-MX", { minimumFractionDigits: 2 })}
                </span>
              </div>
              {concept && (
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Concepto</span>
                  <span className="text-card-foreground">{concept}</span>
                </div>
              )}
              <hr className="border-border" />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Folio</span>
                <span className="font-mono text-xs text-card-foreground">{folio}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Fecha</span>
                <span className="text-card-foreground text-xs">
                  {new Date().toLocaleString("es-MX", {
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 rounded-lg bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-all mt-2"
            >
              Listo
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
